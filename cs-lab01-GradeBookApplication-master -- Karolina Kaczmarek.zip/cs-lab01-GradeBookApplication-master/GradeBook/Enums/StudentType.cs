﻿namespace GradeBooks.Enums
{
    public enum StudentType
    {
        Standard,
        Honors,
        DualEnrolled
    }
}
