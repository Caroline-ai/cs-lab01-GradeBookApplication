﻿

namespace GradeBooks.Enums
{
    public enum GradeBookType
    {
        Standard,
        Ranked,
        ESNU,
        OneToFour,
        SixPoint
    }
}
